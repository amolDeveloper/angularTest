export interface Payment {
    number: String,
    name: String,
    date: Date,
    cvv: String,
    amount: Number
}