import { Payment } from './payment.model';

export interface AppState {
    readonly payment: Payment[];
}