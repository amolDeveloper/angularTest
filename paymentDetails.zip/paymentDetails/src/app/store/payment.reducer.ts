import { Payment } from './payment.model';
import * as PaymentActions from './payment.actions';

const initialState: Payment = {
    number: "1234 5678 2345",
    name: "Amol kodge",
    date: new Date("12-15-2020"),
    cvv: "123",
    amount: 12000
}

export function reducer(state: Payment[] = [initialState], action: PaymentActions.Actions) {
    switch (action.type) {
        case PaymentActions.ADD_PAYMENT:
            return [...state, action.payload]
        default:
            return state
    }
}